import "./App.css";
import HomePage from "./pages/Components/HomePage";

function App() {
  return (
    <div className="App">
      <HomePage />
    </div>
  );
}

export default App;
